# JGCALayer
##核心动画基本使用
###效果图
![Mou icon](https://github.com/mengzhihun6/JGCALayer/blob/master/JGCALayer.gif)

##此Demo所包含的功能
	
    	_dataArray = @[@"01 - CALayer的基本操作",
                       @""02 - 时钟效果",
                       @"03 - 心跳效果/转场动画",
                       @"04 - 转盘",
                       @"05 - 图片折叠",
                       @"06 - 音乐震动条/复制层",
                       @"07 - 倒影",
                       @"08 - 粒子效果",
                       @"09 - QQ粘性布局",
                       @"10 - 微博动画",
                       @"11 - 打马赛克"];
